package com.Commission;

public class CircleMain {

	public static void main(String[] args) {
	
		Circle obj=new Circle(12.0,"Red");
		System.out.println(obj.getInput());
		System.out.println(obj.CircleArea());
		
	}
	}


