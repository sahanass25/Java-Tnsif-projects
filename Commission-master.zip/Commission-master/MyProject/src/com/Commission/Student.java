package com.Commission;

public class Student {

	
		
		public Student() {
			super();
		}
		public void display() {
			System.out.println("Student object is created");
		}

	}