package com.Commission;

public class CommissionMain {

	public static void main(String[] args) {
	Commission obj= new Commission("ABC" , "#erwt,6th cross , xyz" , 123456789, 50000);
	System.out.println(obj);
	obj.totalCommission();

	}

}
