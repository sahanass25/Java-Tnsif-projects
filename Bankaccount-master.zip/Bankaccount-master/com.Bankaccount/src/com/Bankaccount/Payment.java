package com.Bankaccount;

 public interface Payment {
	void process(double amount);

	
 }
	