package com.Student;

public class StudentMain {

	public static void main(String[] args) {
		Student obj=new Student();
		obj.display();
	

	}

}
